﻿@echo off
setlocal
title Diagnostico tecnico do notebook
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Solicitando permissao de Administrador...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Iniciando diagnostico em modo de coleta...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSTICO_NOTEBOOK.ps1"
set "RC=%errorlevel%"
if not "%RC%"=="0" (
    echo.
    echo O diagnostico terminou com codigo %RC%.
    pause
)
exit /b %RC%
