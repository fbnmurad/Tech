﻿#requires -version 5.1
<#
  Reparo conservador do Windows Update.
  Execute somente depois de guardar o ZIP gerado pelo diagnóstico.
  Faz backup por renomeação das pastas de cache; não apaga os backups.
#>

[CmdletBinding()]
param()

$ErrorActionPreference = "Continue"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    Write-Host "Execute pelo arquivo REPARAR_WINDOWS_UPDATE.cmd." -ForegroundColor Red
    Read-Host "Pressione ENTER"
    exit 1
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$desktop = [Environment]::GetFolderPath("Desktop")
$logDir = Join-Path $desktop "Reparo_Windows_Update_$stamp"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
Start-Transcript -Path (Join-Path $logDir "REPARO_COMPLETO.txt") -Force | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " REPARO CONSERVADOR DO WINDOWS UPDATE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Registro do estado anterior
Get-CimInstance Win32_Service |
    Where-Object Name -in @("wuauserv","bits","cryptsvc","UsoSvc","WaaSMedicSvc","DoSvc","TrustedInstaller") |
    Select-Object Name, State, StartMode, Status, ExitCode, PathName |
    Format-Table -AutoSize |
    Out-File (Join-Path $logDir "01_SERVICOS_ANTES.txt") -Encoding utf8 -Width 4096

$policyPaths = @(
    "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate",
    "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
)
foreach ($p in $policyPaths) {
    if (Test-Path $p) {
        "=== $p ===" | Out-File (Join-Path $logDir "02_POLITICAS_ANTES.txt") -Append -Encoding utf8
        Get-ItemProperty $p | Format-List * |
            Out-File (Join-Path $logDir "02_POLITICAS_ANTES.txt") -Append -Encoding utf8 -Width 4096
    }
}

Write-Host "Configurando somente os três serviços essenciais quando estiverem desabilitados..." -ForegroundColor Cyan
$essential = @{
    "wuauserv" = "demand"
    "bits"     = "delayed-auto"
    "cryptsvc" = "auto"
}
foreach ($name in $essential.Keys) {
    $svc = Get-CimInstance Win32_Service -Filter "Name='$name'" -ErrorAction SilentlyContinue
    if ($svc -and $svc.StartMode -eq "Disabled") {
        & sc.exe config $name start= $essential[$name] | Out-Host
    }
}

Write-Host "Parando serviços para recriar os caches..." -ForegroundColor Cyan
foreach ($name in @("bits","wuauserv","cryptsvc")) {
    & net.exe stop $name /y | Out-Host
}

Start-Sleep -Seconds 3

$sd = Join-Path $env:SystemRoot "SoftwareDistribution"
$cr = Join-Path $env:SystemRoot "System32\catroot2"
$sdBackup = "$sd.backup_$stamp"
$crBackup = "$cr.backup_$stamp"

if (Test-Path $sd) {
    try {
        Rename-Item -Path $sd -NewName (Split-Path $sdBackup -Leaf) -ErrorAction Stop
        Write-Host "SoftwareDistribution renomeada para backup." -ForegroundColor Green
    } catch {
        Write-Host "Falha ao renomear SoftwareDistribution: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if (Test-Path $cr) {
    try {
        Rename-Item -Path $cr -NewName (Split-Path $crBackup -Leaf) -ErrorAction Stop
        Write-Host "catroot2 renomeada para backup." -ForegroundColor Green
    } catch {
        Write-Host "Falha ao renomear catroot2: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "Reiniciando serviços..." -ForegroundColor Cyan
foreach ($name in @("cryptsvc","bits","wuauserv")) {
    & net.exe start $name | Out-Host
}

Write-Host ""
Write-Host "Reparando a imagem do Windows..." -ForegroundColor Cyan
& DISM.exe /Online /Cleanup-Image /RestoreHealth 2>&1 |
    Tee-Object -FilePath (Join-Path $logDir "03_DISM_RESTOREHEALTH.txt")

Write-Host ""
Write-Host "Verificando e reparando arquivos protegidos..." -ForegroundColor Cyan
& sfc.exe /scannow 2>&1 |
    Tee-Object -FilePath (Join-Path $logDir "04_SFC_SCANNOW.txt")

Get-CimInstance Win32_Service |
    Where-Object Name -in @("wuauserv","bits","cryptsvc","UsoSvc","WaaSMedicSvc","DoSvc","TrustedInstaller") |
    Select-Object Name, State, StartMode, Status, ExitCode, PathName |
    Format-Table -AutoSize |
    Out-File (Join-Path $logDir "05_SERVICOS_DEPOIS.txt") -Encoding utf8 -Width 4096

Stop-Transcript | Out-Null

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " ETAPA DE REPARO CONCLUIDA" -ForegroundColor Green
Write-Host " Relatorios: $logDir" -ForegroundColor Green
Write-Host " Reinicie o computador e abra o Windows Update novamente." -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Os caches antigos foram preservados como pastas .backup_DATA." -ForegroundColor Yellow
Read-Host "Pressione ENTER para fechar"
