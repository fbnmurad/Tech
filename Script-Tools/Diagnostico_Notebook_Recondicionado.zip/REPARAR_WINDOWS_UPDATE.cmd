﻿@echo off
setlocal
title Reparo conservador do Windows Update
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Solicitando permissao de Administrador...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo ATENCAO:
echo Execute este reparo somente DEPOIS de guardar o ZIP do diagnostico.
echo O processo redefine os caches do Windows Update e executa DISM/SFC.
echo Nenhum arquivo de cache antigo sera apagado; sera renomeado como backup.
echo.
choice /c SN /n /m "Deseja continuar? [S/N]: "
if errorlevel 2 exit /b 0

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0REPARAR_WINDOWS_UPDATE.ps1"
set "RC=%errorlevel%"
if not "%RC%"=="0" (
    echo.
    echo O reparo terminou com codigo %RC%.
    pause
)
exit /b %RC%
