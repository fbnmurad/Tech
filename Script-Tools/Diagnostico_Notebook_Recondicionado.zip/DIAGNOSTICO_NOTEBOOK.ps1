﻿#requires -version 5.1
<#
  Diagnóstico técnico de notebook recondicionado
  Modo: somente leitura / coleta de evidências
  Não instala drivers, não altera licença e não redefine o Windows Update.
#>

[CmdletBinding()]
param()

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    Write-Host "Este diagnóstico precisa ser executado como Administrador." -ForegroundColor Red
    Write-Host "Use o arquivo EXECUTAR_DIAGNOSTICO.cmd." -ForegroundColor Yellow
    Read-Host "Pressione ENTER para sair"
    exit 1
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$desktop = [Environment]::GetFolderPath("Desktop")
$outDir = Join-Path $desktop "Diagnostico_Notebook_$timestamp"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

$results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param(
        [string]$Categoria,
        [string]$Teste,
        [ValidateSet("OK","ATENCAO","FALHA","INFO","NAO_TESTADO")]
        [string]$Status,
        [string]$Detalhes,
        [string]$Recomendacao = ""
    )
    $results.Add([pscustomobject]@{
        Categoria    = $Categoria
        Teste        = $Teste
        Status       = $Status
        Detalhes     = $Detalhes
        Recomendacao = $Recomendacao
    }) | Out-Null

    $color = switch ($Status) {
        "OK"          { "Green" }
        "ATENCAO"     { "Yellow" }
        "FALHA"       { "Red" }
        "INFO"        { "Cyan" }
        "NAO_TESTADO" { "DarkYellow" }
    }
    Write-Host ("[{0}] {1} - {2}" -f $Status, $Categoria, $Teste) -ForegroundColor $color
}

function Save-Text {
    param([string]$Name, [object]$Content)
    $path = Join-Path $outDir $Name
    try {
        $Content | Out-File -FilePath $path -Encoding utf8 -Width 4096
    } catch {
        "Falha ao gerar arquivo: $($_.Exception.Message)" |
            Out-File -FilePath $path -Encoding utf8
    }
}

function Run-CmdToFile {
    param([string]$Command, [string]$FileName)
    $path = Join-Path $outDir $FileName
    try {
        cmd.exe /d /c "$Command" 2>&1 |
            Out-File -FilePath $path -Encoding utf8 -Width 4096
        return $LASTEXITCODE
    } catch {
        "Falha ao executar: $Command`r`n$($_.Exception.Message)" |
            Out-File -FilePath $path -Encoding utf8
        return 999
    }
}

Start-Transcript -Path (Join-Path $outDir "00_TRANSCRICAO_COMPLETA.txt") -Force | Out-Null

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " DIAGNOSTICO TECNICO DE NOTEBOOK RECONDICIONADO" -ForegroundColor Cyan
Write-Host " Coleta sem instalacao e sem reparos automaticos" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------------------
# 1. IDENTIFICAÇÃO DO EQUIPAMENTO E DO WINDOWS
# ---------------------------------------------------------------------------
try {
    $cs      = Get-CimInstance Win32_ComputerSystem
    $csp     = Get-CimInstance Win32_ComputerSystemProduct
    $bios    = Get-CimInstance Win32_BIOS
    $board   = Get-CimInstance Win32_BaseBoard
    $os      = Get-CimInstance Win32_OperatingSystem
    $cpu     = Get-CimInstance Win32_Processor
    $winReg  = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"

    $identity = [pscustomobject]@{
        Fabricante              = $cs.Manufacturer
        Modelo                  = $cs.Model
        TipoSistema             = $cs.SystemType
        NumeroSerieEquipamento  = $bios.SerialNumber
        UUID                    = $csp.UUID
        PlacaMaeFabricante      = $board.Manufacturer
        PlacaMaeProduto         = $board.Product
        PlacaMaeSerie           = $board.SerialNumber
        BIOSFabricante          = $bios.Manufacturer
        BIOSVersao              = ($bios.SMBIOSBIOSVersion -join ", ")
        BIOSData                = $bios.ReleaseDate
        WindowsProduto          = $winReg.ProductName
        WindowsEdicao           = $winReg.EditionID
        WindowsDisplayVersion   = $winReg.DisplayVersion
        WindowsBuild            = "$($winReg.CurrentBuild).$($winReg.UBR)"
        WindowsInstallationType = $winReg.InstallationType
        DataInstalacaoWindows   = $os.InstallDate
        UltimaInicializacao     = $os.LastBootUpTime
        Arquitetura             = $os.OSArchitecture
        Processador             = ($cpu.Name -join " | ")
        Nucleos                 = ($cpu.NumberOfCores -join " | ")
        ProcessadoresLogicos    = ($cpu.NumberOfLogicalProcessors -join " | ")
        RAMTotalGB              = [math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
    }
    $identity | Format-List | Out-String -Width 4096 | Save-Text "01_IDENTIFICACAO_EQUIPAMENTO.txt"

    $badDmi = @($cs.Manufacturer, $cs.Model, $bios.SerialNumber, $board.SerialNumber) |
        Where-Object { [string]::IsNullOrWhiteSpace($_) -or $_ -match "To Be Filled|Default string|System Serial|123456|Unknown" }

    if ($badDmi.Count -gt 0) {
        Add-Result "Identificação" "Dados DMI/BIOS" "ATENCAO" `
            "Há campos genéricos, vazios ou mal programados no BIOS/DMI." `
            "Em recondicionados isso pode indicar troca de placa-mãe ou BIOS não reprogramado corretamente."
    } else {
        Add-Result "Identificação" "Dados DMI/BIOS" "OK" `
            "$($cs.Manufacturer) $($cs.Model); série detectada."
    }

    Add-Result "Windows" "Versão instalada" "INFO" `
        "$($winReg.ProductName), edição $($winReg.EditionID), versão $($winReg.DisplayVersion), build $($winReg.CurrentBuild).$($winReg.UBR)."
} catch {
    Add-Result "Identificação" "Inventário básico" "FALHA" $_.Exception.Message
}

try {
    msinfo32.exe /report (Join-Path $outDir "02_MSINFO32.txt")
} catch {
    Save-Text "02_MSINFO32_ERRO.txt" $_.Exception.Message
}

try {
    Start-Process -FilePath "dxdiag.exe" `
        -ArgumentList "/dontskip /whql:off /t `"$outDir\03_DXDIAG.txt`"" `
        -Wait -WindowStyle Hidden
} catch {
    Save-Text "03_DXDIAG_ERRO.txt" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 2. LICENÇA E INDÍCIOS DE ATIVAÇÃO IRREGULAR
# ---------------------------------------------------------------------------
try {
    $windowsAppId = "55c92734-d682-4d71-983e-d6ec3f16059f"
    $licenses = Get-CimInstance SoftwareLicensingProduct |
        Where-Object {
            $_.ApplicationID -eq $windowsAppId -and
            $_.Name -like "Windows*" -and
            $_.PartialProductKey
        }

    $licenseStatusMap = @{
        0 = "Não licenciado"
        1 = "Licenciado/ativado"
        2 = "Período inicial de tolerância"
        3 = "Período adicional de tolerância"
        4 = "Licença não genuína"
        5 = "Notificação"
        6 = "Tolerância estendida"
    }

    $licenseView = foreach ($lic in $licenses) {
        [pscustomobject]@{
            Nome              = $lic.Name
            DescricaoCanal    = $lic.Description
            StatusCodigo      = $lic.LicenseStatus
            StatusTraduzido   = $licenseStatusMap[[int]$lic.LicenseStatus]
            ChaveParcial      = $lic.PartialProductKey
            Motivo            = ("0x{0:X8}" -f [uint32]$lic.LicenseStatusReason)
            Familia           = $lic.LicenseFamily
            GracePeriodMin    = $lic.GracePeriodRemaining
        }
    }
    $licenseView | Format-List | Out-String -Width 4096 | Save-Text "10_LICENCA_WINDOWS_CIM.txt"

    $sls = Get-CimInstance SoftwareLicensingService
    $oemKeyPresent = -not [string]::IsNullOrWhiteSpace($sls.OA3xOriginalProductKey)
    $oemInfo = [pscustomobject]@{
        ChaveOEMEmbutidaNoFirmware = $oemKeyPresent
        Observacao = "A chave completa não foi gravada no relatório por segurança."
    }
    $oemInfo | Format-List | Out-String | Save-Text "11_CHAVE_OEM_FIRMWARE.txt"

    Run-CmdToFile "cscript.exe //nologo `%windir`%\system32\slmgr.vbs /dlv" "12_SLMGR_DLV.txt" | Out-Null
    Run-CmdToFile "cscript.exe //nologo `%windir`%\system32\slmgr.vbs /xpr" "13_SLMGR_XPR.txt" | Out-Null

    $active = $licenses | Where-Object { $_.LicenseStatus -eq 1 }
    if (-not $active) {
        Add-Result "Licença" "Ativação do Windows" "FALHA" `
            "Nenhuma licença ativa do Windows foi encontrada." `
            "Verifique Configurações > Sistema > Ativação e a documentação de compra."
    } else {
        $desc = ($active.Description -join " | ")
        if ($desc -match "VOLUME_KMSCLIENT|KMS") {
            Add-Result "Licença" "Canal de ativação" "ATENCAO" `
                "Windows ativado por canal de volume/KMS: $desc" `
                "Em notebook pessoal ou vendido no varejo, KMS é suspeito. Confirme a origem da licença com o vendedor."
        } elseif ($desc -match "OEM") {
            Add-Result "Licença" "Canal de ativação" "OK" `
                "Licença ativa em canal OEM: $desc"
        } elseif ($desc -match "RETAIL") {
            Add-Result "Licença" "Canal de ativação" "OK" `
                "Licença ativa em canal Retail: $desc"
        } else {
            Add-Result "Licença" "Canal de ativação" "ATENCAO" `
                "Licença ativa, mas o canal requer análise: $desc" `
                "Consulte os relatórios SLMGR."
        }
    }

    if ($oemKeyPresent) {
        Add-Result "Licença" "Chave OEM no firmware" "OK" `
            "Foi detectada uma chave OEM OA3 gravada no firmware."
    } else {
        Add-Result "Licença" "Chave OEM no firmware" "INFO" `
            "Não foi detectada chave OEM OA3 no firmware." `
            "Isso não prova irregularidade: alguns equipamentos usam licença Retail ou licença digital."
    }

    $sppPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform"
    $spp = Get-ItemProperty $sppPath -ErrorAction SilentlyContinue
    $kmsValues = [pscustomobject]@{
        KeyManagementServiceName = $spp.KeyManagementServiceName
        KeyManagementServicePort = $spp.KeyManagementServicePort
        DisableDnsPublishing     = $spp.DisableDnsPublishing
    }
    $kmsValues | Format-List | Out-String | Save-Text "14_CONFIGURACAO_KMS_REGISTRO.txt"

    if (-not [string]::IsNullOrWhiteSpace($spp.KeyManagementServiceName)) {
        Add-Result "Licença" "Servidor KMS configurado" "ATENCAO" `
            "Há servidor KMS definido manualmente: $($spp.KeyManagementServiceName)." `
            "Em equipamento pessoal, peça explicação e nota fiscal/licença ao vendedor."
    }
} catch {
    Add-Result "Licença" "Auditoria de ativação" "FALHA" $_.Exception.Message
}

# Busca criteriosa por indícios, sem afirmar pirataria automaticamente.
try {
    $regexActivator = "(?i)KMSpico|KMSAuto|AutoKMS|AAct|HEU.?KMS|MAS_AIO|Microsoft.?Activation.?Scripts|HWID.?Activation"
    $suspects = New-Object System.Collections.Generic.List[object]

    try {
        Get-ScheduledTask -ErrorAction SilentlyContinue | ForEach-Object {
            $actionText = ($_.Actions | Out-String)
            if (($_.TaskName + " " + $_.TaskPath + " " + $actionText) -match $regexActivator) {
                $suspects.Add([pscustomobject]@{
                    Tipo="Tarefa agendada"; Nome="$($_.TaskPath)$($_.TaskName)"; Detalhe=$actionText.Trim()
                }) | Out-Null
            }
        }
    } catch {}

    try {
        Get-CimInstance Win32_Service | ForEach-Object {
            if (($_.Name + " " + $_.DisplayName + " " + $_.PathName) -match $regexActivator) {
                $suspects.Add([pscustomobject]@{
                    Tipo="Serviço"; Nome=$_.Name; Detalhe="$($_.DisplayName) | $($_.PathName)"
                }) | Out-Null
            }
        }
    } catch {}

    $uninstallRoots = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    foreach ($root in $uninstallRoots) {
        Get-ItemProperty $root -ErrorAction SilentlyContinue | Where-Object {
            ($_.DisplayName + " " + $_.Publisher + " " + $_.InstallLocation) -match $regexActivator
        } | ForEach-Object {
            $suspects.Add([pscustomobject]@{
                Tipo="Programa instalado"; Nome=$_.DisplayName; Detalhe="$($_.Publisher) | $($_.InstallLocation)"
            }) | Out-Null
        }
    }

    if ($suspects.Count -gt 0) {
        $suspects | Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "15_INDICIOS_ATIVADORES.txt"
        Add-Result "Licença" "Indícios de ativadores" "ATENCAO" `
            "$($suspects.Count) item(ns) compatível(is) com nomes de ativadores foi(ram) encontrado(s)." `
            "Revise 15_INDICIOS_ATIVADORES.txt. Pode haver falso positivo; não conclua sem análise."
    } else {
        Save-Text "15_INDICIOS_ATIVADORES.txt" "Nenhum indício nominal conhecido foi encontrado."
        Add-Result "Licença" "Indícios de ativadores" "OK" `
            "Nenhum serviço, tarefa ou programa com nomes típicos de ativadores foi encontrado."
    }
} catch {
    Add-Result "Licença" "Busca de ativadores" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 3. WINDOWS UPDATE, SERVIÇOS, POLÍTICAS E ATUALIZAÇÕES PENDENTES
# ---------------------------------------------------------------------------
try {
    $serviceNames = "wuauserv","bits","cryptsvc","UsoSvc","WaaSMedicSvc","DoSvc","TrustedInstaller"
    $updateServices = Get-CimInstance Win32_Service |
        Where-Object { $_.Name -in $serviceNames } |
        Select-Object Name, DisplayName, State, StartMode, Status, ExitCode, PathName

    $updateServices | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "20_SERVICOS_WINDOWS_UPDATE.txt"

    foreach ($svc in $updateServices) {
        if ($svc.Name -in @("wuauserv","bits","cryptsvc") -and $svc.StartMode -eq "Disabled") {
            Add-Result "Windows Update" "Serviço $($svc.Name)" "FALHA" `
                "O serviço está desabilitado." `
                "Isso pode impedir a tela do Windows Update de abrir e pode ter sido causado por otimização agressiva, política ou ativador."
        } elseif ($svc.Name -eq "cryptsvc" -and $svc.State -ne "Running") {
            Add-Result "Windows Update" "Serviço Cryptographic Services" "ATENCAO" `
                "CryptSvc não está em execução."
        } else {
            Add-Result "Windows Update" "Serviço $($svc.Name)" "INFO" `
                "Estado=$($svc.State); Inicialização=$($svc.StartMode)."
        }
    }

    $policyPaths = @(
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate",
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU",
        "HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
    )
    $policyText = New-Object System.Collections.Generic.List[string]
    $policyFound = $false
    foreach ($path in $policyPaths) {
        if (Test-Path $path) {
            $policyFound = $true
            $policyText.Add("=== $path ===")
            $policyText.Add(((Get-ItemProperty $path | Format-List * | Out-String -Width 4096)))
        }
    }
    if ($policyFound) {
        $policyText | Save-Text "21_POLITICAS_WINDOWS_UPDATE.txt"
        Add-Result "Windows Update" "Políticas configuradas" "ATENCAO" `
            "Foram encontradas políticas de Windows Update no Registro." `
            "Revise 21_POLITICAS_WINDOWS_UPDATE.txt; algumas podem bloquear o acesso ou redirecionar para WSUS."
    } else {
        Save-Text "21_POLITICAS_WINDOWS_UPDATE.txt" "Nenhuma política explícita encontrada nos caminhos verificados."
        Add-Result "Windows Update" "Políticas configuradas" "OK" `
            "Nenhuma política explícita de Windows Update foi encontrada."
    }

    Run-CmdToFile "netsh winhttp show proxy" "22_PROXY_WINHTTP.txt" | Out-Null
    Run-CmdToFile "ipconfig /all" "23_REDE_IPCONFIG.txt" | Out-Null

    $pendingRebootReasons = New-Object System.Collections.Generic.List[string]
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") {
        $pendingRebootReasons.Add("CBS RebootPending")
    }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") {
        $pendingRebootReasons.Add("Windows Update RebootRequired")
    }
    $pfro = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" `
        -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
    if ($pfro) { $pendingRebootReasons.Add("PendingFileRenameOperations") }

    if ($pendingRebootReasons.Count -gt 0) {
        Add-Result "Windows Update" "Reinicialização pendente" "ATENCAO" `
            ($pendingRebootReasons -join "; ") `
            "Reinicie o notebook antes de interpretar falhas de atualização."
    } else {
        Add-Result "Windows Update" "Reinicialização pendente" "OK" `
            "Nenhum indicador principal de reinicialização pendente foi encontrado."
    }

    try {
        $wuLog = Get-WinEvent -FilterHashtable @{
            LogName="Microsoft-Windows-WindowsUpdateClient/Operational"
            StartTime=(Get-Date).AddDays(-60)
            Level=1,2,3
        } -ErrorAction Stop | Select-Object TimeCreated, Id, LevelDisplayName, Message
        $wuLog | Format-List | Out-String -Width 4096 | Save-Text "24_ERROS_WINDOWS_UPDATE_60_DIAS.txt"
        if ($wuLog.Count -gt 0) {
            Add-Result "Windows Update" "Erros recentes" "ATENCAO" `
                "$($wuLog.Count) evento(s) de erro/alerta nos últimos 60 dias." `
                "Revise 24_ERROS_WINDOWS_UPDATE_60_DIAS.txt."
        } else {
            Add-Result "Windows Update" "Erros recentes" "OK" "Nenhum evento crítico/erro/alerta encontrado no período."
        }
    } catch {
        Save-Text "24_ERROS_WINDOWS_UPDATE_60_DIAS.txt" "Não foi possível ler o log: $($_.Exception.Message)"
        Add-Result "Windows Update" "Log operacional" "ATENCAO" $_.Exception.Message
    }

    try {
        Get-HotFix | Sort-Object InstalledOn -Descending |
            Select-Object HotFixID, Description, InstalledBy, InstalledOn |
            Format-Table -AutoSize | Out-String -Width 4096 |
            Save-Text "25_ATUALIZACOES_INSTALADAS.txt"
    } catch {
        Save-Text "25_ATUALIZACOES_INSTALADAS_ERRO.txt" $_.Exception.Message
    }

    Write-Host "Consultando atualizações pendentes pelo mecanismo nativo do Windows..." -ForegroundColor Cyan
    $job = Start-Job -ScriptBlock {
        $ErrorActionPreference = "Stop"
        $session = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $searcher.Online = $true
        $search = $searcher.Search("IsInstalled=0 and IsHidden=0")
        foreach ($u in $search.Updates) {
            [pscustomobject]@{
                Titulo = $u.Title
                KBs = ($u.KBArticleIDs -join ",")
                Tipo = $u.Type
                RequerReinicio = $u.RebootRequired
                EulaAceita = $u.EulaAccepted
                Baixada = $u.IsDownloaded
            }
        }
    }
    $finished = Wait-Job $job -Timeout 240
    if ($finished) {
        $pendingUpdates = Receive-Job $job
        $pendingUpdates | Format-Table -AutoSize | Out-String -Width 4096 |
            Save-Text "26_ATUALIZACOES_PENDENTES.txt"
        if ($pendingUpdates.Count -gt 0) {
            Add-Result "Windows Update" "Atualizações pendentes" "ATENCAO" `
                "$($pendingUpdates.Count) atualização(ões) pendente(s) detectada(s)." `
                "Revise 26_ATUALIZACOES_PENDENTES.txt."
        } else {
            Add-Result "Windows Update" "Atualizações pendentes" "OK" `
                "A consulta concluiu sem encontrar atualizações pendentes."
        }
    } else {
        Stop-Job $job -ErrorAction SilentlyContinue
        Save-Text "26_ATUALIZACOES_PENDENTES.txt" `
            "A consulta não concluiu. Isso reforça a suspeita de falha no Windows Update, serviço, rede ou política."
        Add-Result "Windows Update" "Consulta online" "FALHA" `
            "O mecanismo nativo não concluiu a consulta." `
            "Analise serviços, políticas, proxy e os eventos do Windows Update."
    }
    Remove-Job $job -Force -ErrorAction SilentlyContinue
} catch {
    Add-Result "Windows Update" "Auditoria geral" "FALHA" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 4. INTEGRIDADE DO WINDOWS
# ---------------------------------------------------------------------------
Write-Host "Verificando a imagem do Windows e arquivos protegidos..." -ForegroundColor Cyan

$dismCheckCode = Run-CmdToFile `
    "DISM.exe /Online /Cleanup-Image /CheckHealth" `
    "30_DISM_CHECKHEALTH.txt"

if ($dismCheckCode -eq 0) {
    Add-Result "Integridade do Windows" "DISM CheckHealth" "OK" `
        "A verificação rápida foi concluída. Leia o relatório para a mensagem exata."
} else {
    Add-Result "Integridade do Windows" "DISM CheckHealth" "ATENCAO" `
        "DISM retornou código $dismCheckCode." `
        "Revise 30_DISM_CHECKHEALTH.txt."
}

$dismScanCode = Run-CmdToFile `
    "DISM.exe /Online /Cleanup-Image /ScanHealth" `
    "31_DISM_SCANHEALTH.txt"

if ($dismScanCode -eq 0) {
    Add-Result "Integridade do Windows" "DISM ScanHealth" "OK" `
        "A análise profunda da imagem foi concluída."
} else {
    Add-Result "Integridade do Windows" "DISM ScanHealth" "ATENCAO" `
        "DISM retornou código $dismScanCode." `
        "Revise 31_DISM_SCANHEALTH.txt."
}

$sfcCode = Run-CmdToFile `
    "sfc.exe /verifyonly" `
    "32_SFC_VERIFYONLY.txt"

if ($sfcCode -eq 0) {
    Add-Result "Integridade do Windows" "SFC VerifyOnly" "OK" `
        "A verificação terminou. O texto do relatório deve confirmar se houve violações."
} else {
    Add-Result "Integridade do Windows" "SFC VerifyOnly" "ATENCAO" `
        "SFC retornou código $sfcCode." `
        "Revise 32_SFC_VERIFYONLY.txt."
}

# ---------------------------------------------------------------------------
# 5. DISCO, SSD/NVME, SISTEMA DE ARQUIVOS E SMART
# ---------------------------------------------------------------------------
try {
    $diskDrives = Get-CimInstance Win32_DiskDrive |
        Select-Object Model, SerialNumber, InterfaceType, MediaType, FirmwareRevision,
            @{N="TamanhoGB";E={[math]::Round($_.Size/1GB,2)}}, Status, PNPDeviceID
    $diskDrives | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "40_DISCOS_WIN32.txt"

    $physicalDisks = Get-PhysicalDisk -ErrorAction Stop
    $physicalDisks |
        Select-Object FriendlyName, SerialNumber, MediaType, BusType,
            @{N="TamanhoGB";E={[math]::Round($_.Size/1GB,2)}},
            HealthStatus, OperationalStatus, FirmwareVersion |
        Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "41_DISCOS_PHYSICALDISK.txt"

    foreach ($disk in $physicalDisks) {
        if ($disk.HealthStatus -eq "Healthy" -and ($disk.OperationalStatus -contains "OK")) {
            Add-Result "Armazenamento" "Saúde $($disk.FriendlyName)" "OK" `
                "HealthStatus=Healthy; OperationalStatus=$($disk.OperationalStatus -join ',')."
        } else {
            Add-Result "Armazenamento" "Saúde $($disk.FriendlyName)" "FALHA" `
                "HealthStatus=$($disk.HealthStatus); OperationalStatus=$($disk.OperationalStatus -join ',')." `
                "Faça backup e teste com a ferramenta oficial do fabricante do SSD."
        }

        try {
            $rel = Get-StorageReliabilityCounter -PhysicalDisk $disk -ErrorAction Stop
            $rel | Format-List * | Out-String -Width 4096 |
                Save-Text ("42_CONFIABILIDADE_{0}.txt" -f (($disk.FriendlyName -replace '[^\w\-]','_')))
            if (($rel.ReadErrorsTotal -gt 0) -or ($rel.WriteErrorsTotal -gt 0) -or ($rel.Temperature -ge 70)) {
                Add-Result "Armazenamento" "Contadores $($disk.FriendlyName)" "ATENCAO" `
                    "Foram detectados erros de leitura/escrita ou temperatura elevada nos contadores." `
                    "Revise o arquivo de confiabilidade correspondente."
            }
        } catch {
            Add-Result "Armazenamento" "Contadores SMART detalhados" "INFO" `
                "O driver/controladora não expôs todos os contadores: $($_.Exception.Message)"
        }
    }

    try {
        $smart = Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus `
            -ErrorAction Stop
        $smart | Format-List * | Out-String -Width 4096 | Save-Text "43_SMART_FAILURE_PREDICT.txt"
        if ($smart | Where-Object { $_.PredictFailure }) {
            Add-Result "Armazenamento" "SMART PredictFailure" "FALHA" `
                "A controladora informou previsão de falha." `
                "Interrompa o uso para dados importantes e providencie substituição."
        } else {
            Add-Result "Armazenamento" "SMART PredictFailure" "OK" `
                "Nenhuma previsão de falha foi informada."
        }
    } catch {
        Add-Result "Armazenamento" "SMART legado" "INFO" `
            "Interface SMART WMI indisponível; comum em alguns NVMe/controladores."
    }
} catch {
    Add-Result "Armazenamento" "Inventário de discos" "FALHA" $_.Exception.Message
}

$chkdskCode = Run-CmdToFile "chkdsk.exe C: /scan" "44_CHKDSK_C_SCAN.txt"
if ($chkdskCode -eq 0) {
    Add-Result "Armazenamento" "CHKDSK online C:" "OK" "Varredura concluída."
} else {
    Add-Result "Armazenamento" "CHKDSK online C:" "ATENCAO" `
        "CHKDSK retornou código $chkdskCode." `
        "Revise 44_CHKDSK_C_SCAN.txt."
}

# ---------------------------------------------------------------------------
# 6. MEMÓRIA RAM
# ---------------------------------------------------------------------------
try {
    $memory = Get-CimInstance Win32_PhysicalMemory |
        Select-Object BankLabel, DeviceLocator, Manufacturer, PartNumber, SerialNumber,
            @{N="CapacidadeGB";E={[math]::Round($_.Capacity/1GB,2)}},
            Speed, ConfiguredClockSpeed, SMBIOSMemoryType
    $memory | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "50_MEMORIA_MODULOS.txt"

    $memTotal = ($memory | Measure-Object Capacity -Sum).Sum
    if ($memTotal -gt 0) {
        Add-Result "Memória" "Módulos detectados" "OK" `
            "$($memory.Count) módulo(s), total físico de $([math]::Round($memTotal/1GB,2)) GB."
    } else {
        Add-Result "Memória" "Módulos detectados" "ATENCAO" `
            "Não foi possível obter a capacidade dos módulos."
    }

    try {
        $memEvents = Get-WinEvent -FilterHashtable @{
            LogName="System"
            ProviderName="Microsoft-Windows-MemoryDiagnostics-Results"
        } -MaxEvents 10 -ErrorAction Stop |
            Select-Object TimeCreated, Id, LevelDisplayName, Message
        $memEvents | Format-List | Out-String -Width 4096 |
            Save-Text "51_RESULTADOS_DIAGNOSTICO_MEMORIA_ANTERIOR.txt"
        Add-Result "Memória" "Teste completo de RAM" "NAO_TESTADO" `
            "O script apenas coletou testes anteriores." `
            "Execute o Diagnóstico de Memória do Windows ou, preferencialmente, o teste UEFI completo do fabricante."
    } catch {
        Save-Text "51_RESULTADOS_DIAGNOSTICO_MEMORIA_ANTERIOR.txt" `
            "Nenhum resultado anterior encontrado ou log indisponível."
        Add-Result "Memória" "Teste completo de RAM" "NAO_TESTADO" `
            "Não há resultado anterior disponível." `
            "RAM exige teste fora do Windows/UEFI para maior confiabilidade."
    }
} catch {
    Add-Result "Memória" "Inventário da RAM" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 7. BATERIA E ENERGIA
# ---------------------------------------------------------------------------
try {
    powercfg.exe /batteryreport /output (Join-Path $outDir "60_RELATORIO_BATERIA.html") | Out-Null
    Add-Result "Bateria" "Relatório de bateria" "INFO" `
        "Relatório HTML gerado em 60_RELATORIO_BATERIA.html."
} catch {
    Add-Result "Bateria" "Relatório de bateria" "ATENCAO" $_.Exception.Message
}

try {
    $staticBatteries = Get-CimInstance -Namespace root\wmi -ClassName BatteryStaticData -ErrorAction Stop
    $fullBatteries = Get-CimInstance -Namespace root\wmi -ClassName BatteryFullChargedCapacity -ErrorAction Stop
    $batteryHealth = foreach ($b in $staticBatteries) {
        $full = $fullBatteries | Where-Object { $_.InstanceName -eq $b.InstanceName } | Select-Object -First 1
        $pct = if ($b.DesignedCapacity -gt 0 -and $full.FullChargedCapacity -gt 0) {
            [math]::Round(($full.FullChargedCapacity / $b.DesignedCapacity) * 100, 1)
        } else { $null }
        [pscustomobject]@{
            Instancia              = $b.InstanceName
            CapacidadeProjeto_mWh  = $b.DesignedCapacity
            CargaMaximaAtual_mWh   = $full.FullChargedCapacity
            SaudePercentual        = $pct
        }
    }
    $batteryHealth | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "61_SAUDE_BATERIA.txt"

    foreach ($b in $batteryHealth) {
        if ($null -eq $b.SaudePercentual) {
            Add-Result "Bateria" "Capacidade útil" "INFO" "O firmware não forneceu dados suficientes."
        } elseif ($b.SaudePercentual -ge 80) {
            Add-Result "Bateria" "Capacidade útil" "OK" `
                "Capacidade máxima atual estimada em $($b.SaudePercentual)% da capacidade de projeto."
        } elseif ($b.SaudePercentual -ge 60) {
            Add-Result "Bateria" "Capacidade útil" "ATENCAO" `
                "Capacidade máxima atual estimada em $($b.SaudePercentual)%." `
                "A bateria apresenta desgaste relevante para um notebook vendido como recondicionado."
        } else {
            Add-Result "Bateria" "Capacidade útil" "FALHA" `
                "Capacidade máxima atual estimada em $($b.SaudePercentual)%." `
                "Considere solicitar substituição da bateria ou devolução conforme a oferta do vendedor."
        }
    }
} catch {
    Add-Result "Bateria" "Capacidade de projeto versus atual" "INFO" `
        "Os dados WMI de capacidade não estão disponíveis: $($_.Exception.Message)"
}

try {
    powercfg.exe /energy /duration 30 /output (Join-Path $outDir "62_RELATORIO_ENERGIA.html") | Out-Null
    Add-Result "Energia" "Análise powercfg" "INFO" `
        "Relatório gerado em 62_RELATORIO_ENERGIA.html; alguns avisos podem ser apenas informativos."
} catch {
    Add-Result "Energia" "Análise powercfg" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 8. BIOS/UEFI, TPM, SECURE BOOT E BITLOCKER
# ---------------------------------------------------------------------------
try {
    $secureBoot = Confirm-SecureBootUEFI -ErrorAction Stop
    if ($secureBoot) {
        Add-Result "Segurança do firmware" "Secure Boot" "OK" "Secure Boot está habilitado."
    } else {
        Add-Result "Segurança do firmware" "Secure Boot" "ATENCAO" `
            "Secure Boot está desabilitado." `
            "Confirme se há motivo legítimo antes de habilitar no UEFI."
    }
} catch {
    Add-Result "Segurança do firmware" "Secure Boot" "INFO" `
        "Não foi possível confirmar: firmware legado, recurso indisponível ou permissão insuficiente."
}

try {
    $tpm = Get-Tpm -ErrorAction Stop
    $tpm | Format-List * | Out-String | Save-Text "70_TPM.txt"
    if ($tpm.TpmPresent -and $tpm.TpmReady) {
        Add-Result "Segurança do firmware" "TPM" "OK" "TPM presente e pronto."
    } else {
        Add-Result "Segurança do firmware" "TPM" "ATENCAO" `
            "TPM presente=$($tpm.TpmPresent); pronto=$($tpm.TpmReady)." `
            "Windows 11 normalmente requer TPM 2.0."
    }
} catch {
    Add-Result "Segurança do firmware" "TPM" "ATENCAO" $_.Exception.Message
}

try {
    $bit = Get-BitLockerVolume -ErrorAction Stop |
        Select-Object MountPoint, VolumeType, VolumeStatus, ProtectionStatus,
            EncryptionMethod, EncryptionPercentage, LockStatus
    $bit | Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "71_BITLOCKER.txt"
    Add-Result "Segurança" "BitLocker/Criptografia" "INFO" `
        "Estado coletado em 71_BITLOCKER.txt. Não foram feitas alterações."
} catch {
    Add-Result "Segurança" "BitLocker/Criptografia" "INFO" `
        "Não foi possível consultar pelo cmdlet: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 9. DISPOSITIVOS, DRIVERS E ASSINATURAS
# ---------------------------------------------------------------------------
try {
    $pnpProblems = Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.ConfigManagerErrorCode -ne 0 } |
        Select-Object Name, PNPClass, Manufacturer, DeviceID, ConfigManagerErrorCode, Status
    $pnpProblems | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "80_DISPOSITIVOS_COM_PROBLEMA.txt"

    if ($pnpProblems.Count -gt 0) {
        Add-Result "Drivers" "Gerenciador de Dispositivos" "FALHA" `
            "$($pnpProblems.Count) dispositivo(s) com código de erro." `
            "Revise 80_DISPOSITIVOS_COM_PROBLEMA.txt antes de aceitar o equipamento."
    } else {
        Add-Result "Drivers" "Gerenciador de Dispositivos" "OK" `
            "Nenhum dispositivo com ConfigManagerErrorCode diferente de zero."
    }

    $drivers = Get-CimInstance Win32_PnPSignedDriver |
        Select-Object DeviceName, DeviceClass, Manufacturer, DriverProviderName,
            DriverVersion, DriverDate, IsSigned, InfName, DeviceID
    $drivers | Export-Csv (Join-Path $outDir "81_DRIVERS_COMPLETOS.csv") `
        -NoTypeInformation -Encoding UTF8

    $unsigned = $drivers | Where-Object { $_.IsSigned -eq $false }
    $unsigned | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "82_DRIVERS_NAO_ASSINADOS.txt"
    if ($unsigned.Count -gt 0) {
        Add-Result "Drivers" "Assinatura digital" "ATENCAO" `
            "$($unsigned.Count) driver(s) reportado(s) como não assinado(s)." `
            "Confirme a origem no site oficial do fabricante."
    } else {
        Add-Result "Drivers" "Assinatura digital" "OK" `
            "Nenhum driver PnP foi reportado como não assinado."
    }

    $oldDrivers = $drivers | Where-Object {
        $_.DriverDate -and ([datetime]$_.DriverDate) -lt (Get-Date).AddYears(-5)
    } | Sort-Object DriverDate
    $oldDrivers | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "83_DRIVERS_COM_DATA_ANTIGA.txt"
    if ($oldDrivers.Count -gt 0) {
        Add-Result "Drivers" "Datas antigas" "INFO" `
            "$($oldDrivers.Count) driver(s) têm data superior a cinco anos." `
            "Data antiga não prova desatualização; compare por modelo e versão no fabricante."
    }

    $classes = @("Display","Net","MEDIA","Camera","Bluetooth","USB")
    $relevant = $drivers | Where-Object { $_.DeviceClass -in $classes }
    $relevant | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "84_DRIVERS_RELEVANTES.txt"
} catch {
    Add-Result "Drivers" "Auditoria de drivers" "FALHA" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 10. FERRAMENTA OFICIAL DO FABRICANTE
# ---------------------------------------------------------------------------
try {
    $installedPrograms = foreach ($root in @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )) {
        Get-ItemProperty $root -ErrorAction SilentlyContinue |
            Where-Object DisplayName |
            Select-Object DisplayName, DisplayVersion, Publisher, InstallDate, InstallLocation
    }
    $installedPrograms | Sort-Object DisplayName |
        Export-Csv (Join-Path $outDir "90_PROGRAMAS_INSTALADOS.csv") `
        -NoTypeInformation -Encoding UTF8

    $oemTools = $installedPrograms | Where-Object {
        $_.DisplayName -match "(?i)Lenovo Vantage|Lenovo System Update|Dell Command.?Update|Dell SupportAssist|HP Support Assistant|MyASUS|Acer Care Center"
    }
    $oemTools | Format-Table -AutoSize | Out-String -Width 4096 |
        Save-Text "91_FERRAMENTAS_OEM.txt"

    if ($oemTools.Count -gt 0) {
        Add-Result "Atualizações OEM" "Ferramenta do fabricante" "OK" `
            "Ferramenta(s) detectada(s): $($oemTools.DisplayName -join ', ')." `
            "Use somente a ferramenta correspondente ao fabricante real do notebook."
    } else {
        Add-Result "Atualizações OEM" "Ferramenta do fabricante" "ATENCAO" `
            "Nenhuma ferramenta oficial comum de atualização foi detectada." `
            "BIOS, firmware e drivers devem ser comparados com o suporte oficial usando modelo e número de série."
    }
} catch {
    Add-Result "Atualizações OEM" "Inventário de software OEM" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 11. ANTIVÍRUS, DEFENDER E FIREWALL
# ---------------------------------------------------------------------------
try {
    $av = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct |
        Select-Object displayName, pathToSignedProductExe, pathToSignedReportingExe, productState
    $av | Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "100_ANTIVIRUS.txt"
    Add-Result "Segurança" "Antivírus registrado" "INFO" `
        "Produto(s): $($av.displayName -join ', ')."
} catch {
    Add-Result "Segurança" "Antivírus registrado" "ATENCAO" $_.Exception.Message
}

try {
    $mp = Get-MpComputerStatus -ErrorAction Stop
    $mp | Format-List * | Out-String -Width 4096 | Save-Text "101_DEFENDER_STATUS.txt"
    if ($mp.AntivirusEnabled -and $mp.RealTimeProtectionEnabled) {
        Add-Result "Segurança" "Microsoft Defender" "OK" `
            "Antivírus e proteção em tempo real habilitados."
    } else {
        Add-Result "Segurança" "Microsoft Defender" "ATENCAO" `
            "Antivírus=$($mp.AntivirusEnabled); tempo real=$($mp.RealTimeProtectionEnabled)." `
            "Pode haver antivírus de terceiros; confirme no relatório."
    }

    $mpp = Get-MpPreference -ErrorAction Stop
    $exclusions = @($mpp.ExclusionPath) + @($mpp.ExclusionProcess) + @($mpp.ExclusionExtension)
    $exclusions = $exclusions | Where-Object { $_ }
    $exclusions | Save-Text "102_EXCLUSOES_DEFENDER.txt"
    if ($exclusions.Count -gt 0) {
        Add-Result "Segurança" "Exclusões do Defender" "ATENCAO" `
            "$($exclusions.Count) exclusão(ões) configurada(s)." `
            "Ativadores e malware podem criar exclusões; revise 102_EXCLUSOES_DEFENDER.txt."
    } else {
        Add-Result "Segurança" "Exclusões do Defender" "OK" "Nenhuma exclusão foi localizada."
    }
} catch {
    Add-Result "Segurança" "Defender" "INFO" `
        "Cmdlets indisponíveis ou antivírus de terceiros ativo: $($_.Exception.Message)"
}

try {
    $fw = Get-NetFirewallProfile |
        Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction, NotifyOnListen
    $fw | Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "103_FIREWALL.txt"
    if ($fw | Where-Object { -not $_.Enabled }) {
        Add-Result "Segurança" "Firewall" "ATENCAO" `
            "Há perfil de firewall desabilitado." `
            "Confirme se um pacote de segurança de terceiros gerencia o firewall."
    } else {
        Add-Result "Segurança" "Firewall" "OK" "Todos os perfis consultados estão habilitados."
    }
} catch {
    Add-Result "Segurança" "Firewall" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 12. EVENTOS DE HARDWARE, TRAVAMENTOS E ARMAZENAMENTO
# ---------------------------------------------------------------------------
try {
    $providers = @(
        "Microsoft-Windows-WHEA-Logger",
        "disk",
        "stornvme",
        "storahci",
        "Ntfs",
        "volmgr",
        "Microsoft-Windows-Kernel-Power",
        "Microsoft-Windows-WER-SystemErrorReporting",
        "Microsoft-Windows-Kernel-PnP"
    )

    $hardwareEvents = Get-WinEvent -FilterHashtable @{
        LogName="System"
        StartTime=(Get-Date).AddDays(-30)
        Level=1,2,3
    } -ErrorAction SilentlyContinue |
        Where-Object { $_.ProviderName -in $providers } |
        Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message

    $hardwareEvents | Format-List | Out-String -Width 4096 |
        Save-Text "110_EVENTOS_HARDWARE_30_DIAS.txt"

    $whea = $hardwareEvents | Where-Object ProviderName -eq "Microsoft-Windows-WHEA-Logger"
    $storageErr = $hardwareEvents | Where-Object ProviderName -in @("disk","stornvme","storahci","Ntfs")
    $kernelPower = $hardwareEvents | Where-Object {
        $_.ProviderName -eq "Microsoft-Windows-Kernel-Power" -and $_.Id -eq 41
    }

    if ($whea.Count -gt 0) {
        Add-Result "Eventos" "Erros WHEA de hardware" "FALHA" `
            "$($whea.Count) evento(s) WHEA nos últimos 30 dias." `
            "Pode indicar CPU, RAM, PCIe, placa-mãe, energia ou firmware. Exige análise dos eventos."
    } else {
        Add-Result "Eventos" "Erros WHEA de hardware" "OK" `
            "Nenhum evento WHEA encontrado nos últimos 30 dias."
    }

    if ($storageErr.Count -gt 0) {
        Add-Result "Eventos" "Erros de disco/controladora" "ATENCAO" `
            "$($storageErr.Count) evento(s) de armazenamento/NTFS." `
            "Revise 110_EVENTOS_HARDWARE_30_DIAS.txt."
    } else {
        Add-Result "Eventos" "Erros de disco/controladora" "OK" `
            "Nenhum evento selecionado de armazenamento foi encontrado no período."
    }

    if ($kernelPower.Count -gt 0) {
        Add-Result "Eventos" "Desligamentos inesperados" "ATENCAO" `
            "$($kernelPower.Count) evento(s) Kernel-Power 41." `
            "Pode ser queda de energia, travamento, bateria, carregador, superaquecimento ou desligamento forçado."
    }
} catch {
    Add-Result "Eventos" "Auditoria do log Sistema" "ATENCAO" $_.Exception.Message
}

try {
    $reliability = Get-CimInstance Win32_ReliabilityRecords -ErrorAction Stop |
        Where-Object { $_.TimeGenerated -ge (Get-Date).AddDays(-30) } |
        Sort-Object TimeGenerated -Descending |
        Select-Object TimeGenerated, SourceName, ProductName, EventIdentifier, Message
    $reliability | Format-List | Out-String -Width 4096 |
        Save-Text "111_HISTORICO_CONFIABILIDADE_30_DIAS.txt"
} catch {
    Save-Text "111_HISTORICO_CONFIABILIDADE_30_DIAS.txt" `
        "Histórico de confiabilidade indisponível: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 13. CPU, GPU, REDE, ÁUDIO, CÂMERA E MONITORES DETECTADOS
# ---------------------------------------------------------------------------
try {
    $cpuInfo = Get-CimInstance Win32_Processor |
        Select-Object Name, Manufacturer, NumberOfCores, NumberOfLogicalProcessors,
            MaxClockSpeed, CurrentClockSpeed, LoadPercentage, Status, ProcessorId
    $cpuInfo | Format-List | Out-String -Width 4096 | Save-Text "120_CPU.txt"
    if ($cpuInfo | Where-Object { $_.Status -and $_.Status -ne "OK" }) {
        Add-Result "Processador" "Estado WMI" "ATENCAO" `
            "O processador não retornou Status=OK."
    } else {
        Add-Result "Processador" "Estado WMI" "OK" "Processador detectado sem alerta de status WMI."
    }

    Get-CimInstance Win32_VideoController |
        Select-Object Name, AdapterCompatibility, DriverVersion, DriverDate,
            VideoProcessor, AdapterRAM, CurrentHorizontalResolution,
            CurrentVerticalResolution, CurrentRefreshRate, Status |
        Format-List | Out-String -Width 4096 | Save-Text "121_GPU_VIDEO.txt"

    Get-NetAdapter -IncludeHidden |
        Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress, DriverInformation |
        Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "122_ADAPTADORES_REDE.txt"

    Get-CimInstance Win32_SoundDevice |
        Select-Object Name, Manufacturer, Status, DeviceID |
        Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "123_AUDIO.txt"

    Get-CimInstance Win32_DesktopMonitor |
        Select-Object Name, MonitorManufacturer, ScreenHeight, ScreenWidth, Status, PNPDeviceID |
        Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "124_MONITORES.txt"

    $camera = Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.PNPClass -eq "Camera" -or $_.Name -match "(?i)camera|webcam" } |
        Select-Object Name, Manufacturer, Status, ConfigManagerErrorCode, DeviceID
    $camera | Format-Table -AutoSize | Out-String -Width 4096 | Save-Text "125_CAMERA.txt"
    if ($camera.Count -gt 0) {
        Add-Result "Periféricos" "Câmera detectada" "OK" `
            "$($camera.Name -join ', ')."
    } else {
        Add-Result "Periféricos" "Câmera detectada" "ATENCAO" `
            "Nenhuma câmera foi localizada pelo inventário." `
            "Pode estar desabilitada no UEFI, ter obturador físico, driver ausente ou o modelo não possuir câmera."
    }
} catch {
    Add-Result "Hardware detectado" "Inventário de periféricos" "ATENCAO" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# 14. LIMITES E CHECKLIST FÍSICO
# ---------------------------------------------------------------------------
$manualChecklist = @"
CHECKLIST FÍSICO OBRIGATÓRIO — NÃO AUTOMATIZÁVEL POR SCRIPT

1. TECLADO
   - Testar todas as teclas, inclusive Fn, setas, F1-F12 e teclado numérico.
   - Uma tecla que só responde quando pressionada com força indica possível desgaste,
     sujeira, membrana, cabo flat ou teclado defeituoso. Não é ajuste de sensibilidade.

2. TELA
   - Exibir fundos branco, preto, vermelho, verde e azul.
   - Procurar pixels mortos, manchas, vazamento de luz, cintilação e linhas.
   - Movimentar lentamente a tampa para identificar falha de cabo flat/dobradiça.

3. PORTAS E CIRCUITOS EXTERNOS
   - Testar cada USB com leitura e gravação.
   - Testar HDMI/DisplayPort, leitor de cartão, áudio e rede, quando existentes.
   - Verificar folga, oxidação, aquecimento ou desconexão intermitente.

4. CARREGADOR E CONECTOR
   - Confirmar potência e tensão compatíveis com a etiqueta do notebook.
   - Movimentar levemente o plugue; a carga não deve interromper.
   - Não usar carregador genérico subdimensionado.

5. BATERIA
   - Verificar estufamento, tampa levantada, touchpad pressionado ou carcaça deformada.
   - Conferir capacidade no relatório 60_RELATORIO_BATERIA.html.

6. RESFRIAMENTO
   - Ouvir ventoinha, procurar ruído de atrito e observar aquecimento anormal.
   - Cheiro de queimado, desligamentos ou redução forte de desempenho exigem inspeção técnica.

7. ÁUDIO, MICROFONE, CÂMERA E WI-FI
   - Fazer gravação de voz, chamada de vídeo e teste de conexão em 2,4/5 GHz.

8. DOBRADIÇAS E CARCAÇA
   - Procurar trincas, parafusos ausentes, folga e marcas de abertura inadequada.

9. TESTE UEFI DO FABRICANTE
   - Executar o diagnóstico completo fora do Windows.
   - Em Lenovo: UEFI Diagnostics/Lenovo Diagnostics.
   - Em Dell: F12 > Diagnostics (ePSA).
   - Em HP: Esc/F2 > HP PC Hardware Diagnostics UEFI.

10. INSPEÇÃO ELÉTRICA PROFISSIONAL
   - Circuitos, soldas, MOSFETs, linhas de alimentação e sinais só podem ser
     confirmados com desmontagem, inspeção, multímetro, fonte assimétrica,
     osciloscópio e/ou ferramentas de bancada.
"@
Save-Text "130_CHECKLIST_FISICO_OBRIGATORIO.txt" $manualChecklist
Add-Result "Limitações" "Integridade elétrica dos circuitos" "NAO_TESTADO" `
    "Software não consegue certificar soldas, MOSFETs, trilhas, conectores ou placa-mãe." `
    "Faça o checklist físico e o diagnóstico UEFI; suspeitas exigem bancada eletrônica."

# ---------------------------------------------------------------------------
# 15. RESUMO FINAL
# ---------------------------------------------------------------------------
$results |
    Sort-Object @{Expression={
        switch ($_.Status) {
            "FALHA" {0}
            "ATENCAO" {1}
            "NAO_TESTADO" {2}
            "INFO" {3}
            "OK" {4}
        }
    }}, Categoria, Teste |
    Export-Csv (Join-Path $outDir "RESUMO_DIAGNOSTICO.csv") -NoTypeInformation -Encoding UTF8

$summaryText = New-Object System.Collections.Generic.List[string]
$summaryText.Add("DIAGNÓSTICO TÉCNICO DE NOTEBOOK RECONDICIONADO")
$summaryText.Add("Gerado em: $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')")
$summaryText.Add("")
foreach ($status in "FALHA","ATENCAO","NAO_TESTADO","INFO","OK") {
    $count = ($results | Where-Object Status -eq $status).Count
    $summaryText.Add("${status}: $count")
}
$summaryText.Add("")
$summaryText.Add("PRIORIDADE DE ANÁLISE")
$summaryText.Add("====================")
foreach ($r in ($results | Where-Object Status -in @("FALHA","ATENCAO","NAO_TESTADO"))) {
    $summaryText.Add("")
    $summaryText.Add("[$($r.Status)] $($r.Categoria) - $($r.Teste)")
    $summaryText.Add("Detalhes: $($r.Detalhes)")
    if ($r.Recomendacao) { $summaryText.Add("Recomendação: $($r.Recomendacao)") }
}
$summaryText | Save-Text "RESUMO_LEIA_PRIMEIRO.txt"

$css = @"
<style>
body { font-family: Segoe UI, Arial, sans-serif; margin: 28px; color: #222; }
h1 { font-size: 24px; }
table { border-collapse: collapse; width: 100%; }
th { background: #1f4e78; color: white; padding: 8px; text-align: left; }
td { border: 1px solid #ccc; padding: 7px; vertical-align: top; }
tr:nth-child(even) { background: #f5f5f5; }
</style>
"@
$results |
    Sort-Object Categoria, Teste |
    ConvertTo-Html -Head $css -Title "Diagnóstico do notebook" `
        -PreContent "<h1>Diagnóstico técnico do notebook</h1><p>Gerado em $(Get-Date)</p>" |
    Out-File (Join-Path $outDir "RESUMO_DIAGNOSTICO.html") -Encoding utf8

Stop-Transcript | Out-Null

$zipPath = Join-Path $desktop "Diagnostico_Notebook_$timestamp.zip"
try {
    Compress-Archive -Path $outDir -DestinationPath $zipPath -CompressionLevel Optimal -Force
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host " DIAGNOSTICO CONCLUIDO" -ForegroundColor Green
    Write-Host " Pasta: $outDir" -ForegroundColor Green
    Write-Host " ZIP:   $zipPath" -ForegroundColor Green
    Write-Host " Abra primeiro: RESUMO_LEIA_PRIMEIRO.txt" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
} catch {
    Write-Host "Relatórios gerados em $outDir, mas o ZIP falhou: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Nenhum reparo foi realizado. Envie o ZIP para análise técnica." -ForegroundColor Cyan
Read-Host "Pressione ENTER para fechar"
